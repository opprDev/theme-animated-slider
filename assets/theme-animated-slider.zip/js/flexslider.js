/*
Copyright 2016 CalliTech
*/

$('.flexslider').flexslider({
	animation: "slide",
	controlNav: false
});
